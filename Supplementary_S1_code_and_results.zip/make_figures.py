import json, numpy as np, matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from derive_w import derive_w
from reproduce_revision import LAYUPS
from laminate import ALLOYS
plt.rcParams.update({"font.family": "serif", "font.serif": ["Times New Roman", "DejaVu Serif"], "font.size": 9,
                     "axes.linewidth": 0.8, "xtick.direction": "in", "ytick.direction": "in", "savefig.dpi": 1000})
D = json.load(open("results_revision.json"))
OUT = "./"
def save(fig, name):
    fig.savefig(OUT + name + ".tif", dpi=1000, bbox_inches="tight", pil_kwargs={"compression": "tiff_lzw"})
    fig.savefig(OUT + name + ".png", dpi=200, bbox_inches="tight")
    plt.close(fig)
def hgrid(ax):
    ax.yaxis.grid(True, linestyle="--", alpha=0.25, linewidth=0.6); ax.set_axisbelow(True)

# Figure 1: weight saving by criterion and alloy (QI) plus tailored strength cells
rng = np.random.default_rng(20261010)
w, ci, ai, _ = derive_w(200000, rng)
rng2 = np.random.default_rng(20261010)
wt, cit, ait, _ = derive_w(200000, rng2, strength_layup=LAYUPS["Tailored 50/40/10"])
data, labels, fills = [], [], []
crit = ["Bending\nstiffness", "In-plane\nstiffness", "Strength\n(QI)"]
for j in range(3):
    for i, a in enumerate(ALLOYS):
        data.append(100 * w[(ci == j) & (ai == i)]); labels.append(crit[j] + "\n" + a); fills.append("0.85" if i == 0 else "0.55")
for i, a in enumerate(ALLOYS):
    data.append(100 * wt[(cit == 2) & (ait == i)]); labels.append("Strength\n(50/40/10)\n" + a); fills.append("0.85" if i == 0 else "0.55")
fig, ax = plt.subplots(figsize=(7.0, 3.2))
ax.axhspan(10, 25, color="0.92", zorder=0)
ax.axhline(0, color="k", linewidth=0.8)
bp = ax.boxplot(data, whis=(5, 95), showfliers=False, patch_artist=True, widths=0.6,
                medianprops=dict(color="k", linewidth=1.2))
for p, f in zip(bp["boxes"], fills):
    p.set_facecolor(f); p.set_edgecolor("k"); p.set_linewidth(0.7)
ax.set_xticks(range(1, len(labels) + 1)); ax.set_xticklabels(labels, fontsize=7)
ax.set_ylabel("Weight saving, w (%)"); hgrid(ax)
save(fig, "Figure_1")

# Figure 2: break-even design strain for strength-critical members
c = D["strain_curve"]; eps = np.array(c["eps"]) * 1e3
fig, ax = plt.subplots(figsize=(3.5, 2.9))
styles = {"Quasi-isotropic 25/50/25 | 2024-T3": ("k", "-"), "Quasi-isotropic 25/50/25 | 7075-T6": ("k", "--"),
          "Tailored 50/40/10 | 2024-T3": ("0.5", "-"), "Tailored 50/40/10 | 7075-T6": ("0.5", "--")}
for k, (col, ls) in styles.items():
    lay, al = k.split(" | ")
    ax.plot(eps, c["curves"][k], color=col, linestyle=ls, linewidth=1.2,
            label=("QI" if lay.startswith("Quasi") else "50/40/10") + ", " + al)
ax.axhline(0, color="k", linewidth=0.6); ax.axvline(4.0, color="k", linewidth=0.6, linestyle=":")
ax.set_xlabel("Ultimate design strain, ε$_{design}$ (×10$^{-3}$)"); ax.set_ylabel("Weight saving before φ (%)")
ax.set_xlim(3.0, 6.5); ax.set_ylim(-75, 60); hgrid(ax); ax.legend(frameon=False, fontsize=7, loc="lower right")
save(fig, "Figure_2")

# Figure 3: cumulative net benefit vs flight hours
S = D["scenarios"]
def scen_curve(name, k, FH, v, dEval, w):
    h = np.linspace(0, FH, 400); return h, w * k * h * v / 1000 * 3.15 - dEval
fig, ax = plt.subplots(figsize=(3.5, 2.9))
spec = [("Central", 0.025, 70000, 700, "k", "-"), ("Metal-favourable", 0.025, 70000, 700, "0.45", "-"),
        ("Adverse corner", 0.020, 50000, 600, "k", ":"),
        ("Strength-critical 2024-T3, quasi-isotropic", 0.025, 70000, 700, "0.45", "--"),
        ("Strength-critical 7075-T6, quasi-isotropic", 0.025, 70000, 700, "k", "--")]
lab = {"Central": "Central", "Metal-favourable": "Metal-favourable", "Adverse corner": "Adverse corner",
       "Strength-critical 2024-T3, quasi-isotropic": "Strength-critical 2024-T3, QI",
       "Strength-critical 7075-T6, quasi-isotropic": "Strength-critical 7075-T6, QI"}
for name, k, FH, v, col, ls in spec:
    s = S[name]; h, y = scen_curve(name, k, FH, v, s["B_C"] - s["B_Al"], s["w"])
    ax.plot(h / 1000, y, color=col, linestyle=ls, linewidth=1.2, label=lab[name])
ax.axhline(0, color="k", linewidth=0.6)
ax.set_xlabel("Flight hours (×10$^{3}$ FH)"); ax.set_ylabel("Cumulative net benefit (kg CO$_2$e kg$^{-1}$)")
hgrid(ax); ax.legend(frameon=False, fontsize=6.5, loc="lower left")
save(fig, "Figure_3")

# Figure 4: Spearman rank correlations with net benefit (main case)
sp = D["mc_tailored_strength_selective"]["spearman_net"]
names = {"w": "Weight saving w", "FH": "Lifetime flight hours H", "BTF_A": "Aluminium buy-to-fly β$_A$",
         "v": "Block speed v", "k": "Marginal fuel burn κ", "sc": "Scrap credit χ", "E_Al": "Primary Al factor e$_{Al}$",
         "E_CF": "Carbon fibre factor e$_{CF}$", "E_res": "Resin factor e$_{res}$", "BTF_C": "CFRP buy-to-fly β$_C$",
         "E_proc": "Process burden e$_{proc}$", "wf": "Fibre mass fraction f$_{CF}$"}
items = sorted(sp.items(), key=lambda kv: abs(kv[1]))
fig, ax = plt.subplots(figsize=(3.5, 3.0))
ax.barh(range(len(items)), [v for _, v in items], color=["0.35" if v >= 0 else "0.75" for _, v in items], edgecolor="k", linewidth=0.5)
ax.set_yticks(range(len(items))); ax.set_yticklabels([names[k] for k, _ in items], fontsize=7)
ax.axvline(0, color="k", linewidth=0.6); ax.set_xlabel("Spearman r$_s$ with net benefit")
ax.xaxis.grid(True, linestyle="--", alpha=0.25, linewidth=0.6); ax.set_axisbelow(True)
save(fig, "Figure_4")

# Figure 5: ETS share vs allowance price
pc = np.linspace(0, 200, 201)
fig, ax = plt.subplots(figsize=(3.5, 2.9))
for pf, col in ((640, "0.55"), (800, "k"), (1000, "0.3")):
    for s, ls in ((0.44, "-"), (1.0, "--")):
        sh = 100 * s * 3.15 * pc / (pf + s * 3.15 * pc)
        ax.plot(pc, sh, color=col, linestyle=ls, linewidth=1.1, label=f"fuel €{pf}/t" if s == 0.44 else None)
ax.set_xlabel("EU ETS allowance price (€ t$^{-1}$ CO$_2$)"); ax.set_ylabel("ETS share of incentive (%)")
ax.set_xlim(0, 200); ax.set_ylim(0, 50); hgrid(ax); ax.legend(frameon=False, fontsize=7, loc="upper left")
save(fig, "Figure_5")

# Graphical abstract
fig, axs = plt.subplots(1, 2, figsize=(10, 4.2))
ax = axs[0]
for k, (col, ls) in styles.items():
    lay, al = k.split(" | ")
    ax.plot(eps, c["curves"][k], color=col, linestyle=ls, linewidth=1.8, label=("Quasi-isotropic" if lay.startswith("Quasi") else "Tailored 50/40/10") + ", " + al)
ax.axhline(0, color="k", linewidth=0.8); ax.axvline(4.0, color="k", linewidth=0.8, linestyle=":")
ax.set_xlabel("Ultimate design strain (×10$^{-3}$)", fontsize=11); ax.set_ylabel("Strength-critical weight saving (%)", fontsize=11)
ax.set_xlim(3, 6.5); ax.set_ylim(-75, 60); ax.legend(frameon=False, fontsize=9, loc="lower right"); hgrid(ax)
ax.set_title("Where CFRP is lighter than aluminium", fontsize=12)
ax = axs[1]
pol = [("Quasi-isotropic,\nindiscriminate", "mc_indiscriminate"), ("Tailored,\nindiscriminate", "mc_tailored_strength_indiscriminate"),
       ("Tailored,\nselective", "mc_tailored_strength_selective"), ("Quasi-isotropic,\nselective", "mc_main")]
vals = [100 * D[k]["P_net_positive"] for _, k in pol]
ax.barh(range(len(pol)), vals, color=["0.75", "0.55", "0.35", "0.2"], edgecolor="k")
for i, v in enumerate(vals): ax.text(v - 2, i, f"{v:.1f}%", va="center", ha="right", color="w", fontsize=11)
ax.set_yticks(range(len(pol))); ax.set_yticklabels([p for p, _ in pol], fontsize=10)
ax.set_xlim(0, 100); ax.set_xlabel("Draws with positive net life-cycle CO$_2$e benefit (%)", fontsize=11)
ax.set_title("Climate balance by substitution policy", fontsize=12)
fig.tight_layout()
fig.savefig(OUT + "Graphical_abstract.tif", dpi=300, bbox_inches="tight", pil_kwargs={"compression": "tiff_lzw"})
fig.savefig(OUT + "Graphical_abstract.png", dpi=200, bbox_inches="tight")
