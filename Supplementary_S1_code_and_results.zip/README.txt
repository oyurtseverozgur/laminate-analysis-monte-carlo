Supplementary material S1
Design-dependent weight saving governs the life-cycle carbon balance of carbon-fibre composite substitution for aerospace aluminium

Files
  laminate.py            Lamina and alloy properties; classical lamination theory (Eqs. 1-2)
  derive_w.py            Weight saving from material indices on a consistent ultimate-load basis (Eqs. 3-9)
  model4.py              Monte Carlo life-cycle and incentive model with Iman-Conover rank correlation (Eqs. 10-16)
  reproduce_revision.py  Reproduces every table and statistic of the manuscript; writes results_revision.json
  make_figures.py        Reproduces Figures 1-5 and the graphical abstract from results_revision.json
  results_revision.json  Output of reproduce_revision.py (seed 20261010, 200,000 draws)

Requirements: Python 3.10 or later, numpy, scipy, matplotlib.
Run:  python reproduce_revision.py   then   python make_figures.py
Run time is about 20 s on a desktop computer.
