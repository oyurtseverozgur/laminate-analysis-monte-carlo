
import numpy as np

# --- Lamina and alloy properties (open literature; see Table 2 of the manuscript) ---
# IM7/8552 unidirectional carbon/epoxy prepreg, Vf ~ 0.57, RT dry
# RTD values from the NCAMP statistical analysis report (NCP-RP-2009-028 Rev B):
# E1 normalized mean 22.99 Msi (Table 4-2); E2 1.30 Msi (Table 4-5); G12 0.68 Msi (Table 4-11);
# nu12 0.316 (Table 3-3); cured composite density 1.58 g/cc at 57.3% fibre volume.
MSI = 6.894757e9
LAMINA = dict(E1=22.99*MSI, E2=1.30*MSI, G12=0.68*MSI, nu12=0.316, rho=1580.0)
# Wrought aerospace aluminium (MMPDS-type design values)
# A-basis room-temperature design allowables, sheet, L direction, from MIL-HDBK-5J:
# 2024-T3, Table 3.2.3.0(b1), 0.010-0.128 in: Ftu 64 ksi, Fty 47 ksi, E 10.5 Msi, rho 0.100 lb/in3
# 7075-T6, Table 3.7.6.0(b1), 0.040-0.125 in: Ftu 78 ksi, Fty 70 ksi, E 10.3 Msi, rho 0.101 lb/in3
KSI = 6.894757e6; LBIN3 = 27679.9
ALLOYS = {
    '2024-T3': dict(E=10.5*MSI, rho=0.100*LBIN3, Fty=47*KSI, Ftu=64*KSI),
    '7075-T6': dict(E=10.3*MSI, rho=0.101*LBIN3, Fty=70*KSI, Ftu=78*KSI),
}
EPS_DESIGN = 0.004   # CFRP damage-tolerance design strain limit (BVID-driven), 4000 microstrain

def Qbar(theta, p):
    """Transformed reduced stiffness of one ply, ply angle theta in radians."""
    nu21 = p['nu12'] * p['E2'] / p['E1']
    d = 1 - p['nu12'] * nu21
    Q = np.array([[p['E1']/d, p['nu12']*p['E2']/d, 0.0],
                  [p['nu12']*p['E2']/d, p['E2']/d, 0.0],
                  [0.0, 0.0, p['G12']]])
    c, s = np.cos(theta), np.sin(theta)
    T = np.array([[c*c, s*s, 2*c*s],
                  [s*s, c*c, -2*c*s],
                  [-c*s, c*s, c*c - s*s]])
    R = np.diag([1.0, 1.0, 2.0])
    return np.linalg.inv(T) @ Q @ R @ T @ np.linalg.inv(R)

def laminate_inplane(angles_deg, p=LAMINA):
    """Effective in-plane engineering constants of a symmetric, balanced laminate."""
    n = len(angles_deg)
    A = sum(Qbar(np.deg2rad(a), p) for a in angles_deg) / n   # per unit thickness
    a = np.linalg.inv(A)
    Ex = 1.0 / a[0, 0]
    Ey = 1.0 / a[1, 1]
    Gxy = 1.0 / a[2, 2]
    nuxy = -a[0, 1] / a[0, 0]
    return dict(Ex=Ex, Ey=Ey, Gxy=Gxy, nuxy=nuxy)

QI = [0, 45, -45, 90]     # quasi-isotropic stacking sequence