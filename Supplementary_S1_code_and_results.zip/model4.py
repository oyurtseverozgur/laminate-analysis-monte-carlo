
import numpy as np, json
from scipy import stats
from derive_w import derive_w

N = 200000; EF = 3.15

def run(seed=20261010, corr=True, price="sourced", eol=False, basis="ultimate", eps_design=None, strength_layup=None,
        w_mode='derived_selective', scrap_cap=1.0):
    rng = np.random.default_rng(seed)
    tri = lambda a,m,b: rng.triangular(a,m,b,N); uni = lambda a,b: rng.uniform(a,b,N)
    g = {}
    if w_mode == 'empirical':
        g['w'] = tri(0.10, 0.20, 0.25); ci = ai = None
    else:
        w_raw, ci, ai, aux = derive_w(N, rng, basis=basis, eps_design=eps_design, strength_layup=strength_layup)
        if w_mode == 'derived_selective':
            # resample until all draws are substitution-viable (w > 0)
            bad = w_raw <= 0
            while bad.any():
                rep, ci_r, ai_r, _ = derive_w(int(bad.sum()), rng, basis=basis, eps_design=eps_design, strength_layup=strength_layup)
                w_raw[bad] = rep; ci[bad] = ci_r; ai[bad] = ai_r
                bad = w_raw <= 0
        g['w'] = w_raw
    g['E_Al']=uni(6.7,15.1); g['sc']=uni(0, scrap_cap)
    g['BTF_A']=tri(1.5,8,20); g['E_CF']=tri(13.0,24.0,34.1); g['wf']=uni(0.60,0.68)
    g['E_res']=uni(2.00,6.43); g['E_proc']=tri(2,5,10); g['BTF_C']=tri(1.05,1.30,1.45)
    g['k']=uni(0.020,0.030); g['FH']=tri(50000,70000,100000); g['v']=uni(600,800)
    if price == 'sourced': g['pf']=tri(640,734,816); g['pc']=tri(65,75,84)
    else:                  g['pf']=tri(600,800,1000); g['pc']=tri(50,80,130)
    g['sETS']=tri(0.30,0.44,0.60); g['r']=tri(0.04,0.08,0.12); g['T']=uni(20,30)
    g['E_eol']=uni(-2,3) if eol else np.zeros(N)
    if corr:
        pairs={('E_CF','E_proc'):0.5,('E_CF','E_res'):0.4,('BTF_A','w'):0.3,
               ('pf','pc'):0.4,('FH','v'):0.3,('r','T'):-0.3}
        names=sorted({n for p in pairs for n in p}); idx={n:i for i,n in enumerate(names)}
        C=np.eye(len(names))
        for (a,b),rr in pairs.items(): C[idx[a],idx[b]]=C[idx[b],idx[a]]=rr
        L=np.linalg.cholesky(C); Z=rng.standard_normal((N,len(names)))@L.T
        for n in names:
            order=np.argsort(np.argsort(Z[:,idx[n]])); srt=np.argsort(g[n], kind='stable')
            g[n]=g[n][srt][order]
            if n=='w' and ci is not None:   # keep the design-criterion and alloy labels attached to w
                ci=ci[srt][order]; ai=ai[srt][order]
    Al = g['BTF_A']*g['E_Al'] - (g['BTF_A']-1)*g['sc']*(g['E_Al']-0.52)
    Cc = (1-g['w'])*(g['BTF_C']*(g['wf']*g['E_CF']+(1-g['wf'])*g['E_res'])+g['E_proc']+g['E_eol'])
    dE = Cc-Al; D = g['FH']*g['v']; fuel = g['w']*g['k']*D/1000; co2 = fuel*EF; net = co2-dE
    a = (1-(1+g['r'])**(-g['T']))/(g['r']*g['T']); ft = fuel/1000
    WPf = a*ft*g['pf']/g['w']; WPe = a*ft*EF*g['sETS']*g['pc']/g['w']; sh = WPe/(WPf+WPe)
    q = lambda x: [float(np.percentile(x,p)) for p in (5,50,95)]
    out = {'w':q(g['w']),'dE_kg':q(dE),'co2_saved_kg':q(co2),'net_kg':q(net),
           'P_net_positive':float(np.mean(net>0)),'P_dE_positive':float(np.mean(dE>0)),
           'WP_fuel':q(WPf),'WP_ets':q(WPe),'WP_tot':q(WPf+WPe),'share_ets':q(sh*100),
           'ratio_co2_over_CFRP':q(co2/Cc),'Al_burden':q(Al),'CFRP_burden':q(Cc),
           'co2_per_kg_saved':q(co2/g['w']),'P_share_gt_20':float(np.mean(sh>0.20)),
           'P_share_gt_15':float(np.mean(sh>0.15))}
    nm=['w','E_Al','sc','BTF_A','E_CF','wf','E_res','E_proc','BTF_C','k','FH','v']
    out['spearman_net']={n:float(stats.spearmanr(g[n],net)[0]) for n in nm}
    out['spearman_share']={n:float(stats.spearmanr(g[n],sh)[0]) for n in ['pf','pc','sETS','r','T','w','k','FH','v']}
    return out, g, dict(dE=dE,net=net,co2=co2,share=sh,ci=ci,ai=ai)