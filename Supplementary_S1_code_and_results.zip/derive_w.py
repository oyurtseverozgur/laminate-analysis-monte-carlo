import numpy as np
from laminate import LAMINA, ALLOYS, EPS_DESIGN, laminate_inplane, QI

FOS = 1.5  # ultimate factor of safety (ultimate load = 1.5 x limit load)


def al_strength_allowable(al, basis="ultimate"):
    """Aluminium allowable stress expressed on the same load basis as the CFRP design strain.
    'ultimate' (main case): the metal must not yield at limit load and must not fail at ultimate
    load, so at ultimate load the governing stress is min(Ftu, FOS*Fty).
    'mixed': Fty compared directly with the ultimate-level CFRP allowable (mixed load levels)."""
    if basis == "ultimate":
        return min(al["Ftu"], FOS * al["Fty"])
    return al["Fty"]


def derive_w(N, rng, eps_design=None, alloy_mix=(0.6, 0.4),
             criterion_mix=(0.40, 0.20, 0.40), phi_tri=(1.00, 1.15, 1.35),
             basis="ultimate", layup=QI, strength_layup=None):
    lam = laminate_inplane(layup, LAMINA)
    Eqi = lam["Ex"]; rho_c = LAMINA["rho"]
    eps = EPS_DESIGN if eps_design is None else eps_design
    sig_c = Eqi * eps
    Es = laminate_inplane(strength_layup, LAMINA)["Ex"] if strength_layup is not None else Eqi
    sig_s = Es * eps
    names = list(ALLOYS)
    ai = rng.choice(len(names), N, p=np.array(alloy_mix))
    ci = rng.choice(3, N, p=np.array(criterion_mix))       # 0 bending, 1 in-plane, 2 strength
    E_al = np.array([ALLOYS[n]["E"] for n in names])[ai]
    rho_al = np.array([ALLOYS[n]["rho"] for n in names])[ai]
    S_al = np.array([al_strength_allowable(ALLOYS[n], basis) for n in names])[ai]
    ratio = np.empty(N)
    m = ci == 0; ratio[m] = (rho_c / rho_al[m]) * (E_al[m] / Eqi) ** (1 / 3)
    m = ci == 1; ratio[m] = (rho_c / rho_al[m]) * (E_al[m] / Eqi)
    m = ci == 2; ratio[m] = (rho_c / rho_al[m]) * (S_al[m] / sig_s)
    phi = rng.triangular(*phi_tri, N)
    w = 1.0 - phi * ratio
    return w, ci, ai, dict(Eqi=Eqi, sig_c=sig_c, ratio=ratio, phi=phi)
