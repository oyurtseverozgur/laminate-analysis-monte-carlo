"""Reproduces every table and statistic of the revised manuscript.
Requires laminate.py, derive_w.py and model4.py in the same folder (Python 3, numpy, scipy)."""
import json
import numpy as np
from scipy.optimize import brentq
from laminate import LAMINA, ALLOYS, EPS_DESIGN, laminate_inplane, QI
from derive_w import derive_w, al_strength_allowable
import model4

EF, E_REC = 3.15, 0.52
CRITERIA = ["Bending stiffness", "In-plane stiffness", "Strength"]
SEED = 20261010


def pct(x, probs=(5, 50, 95)):
    return [float(np.percentile(x, p)) for p in probs]


def layup(f0, f45, f90, n=100):
    k0, k45, k90 = (int(round(f * n)) for f in (f0, f45, f90))
    return [0] * k0 + [45] * (k45 // 2) + [-45] * (k45 // 2) + [90] * k90


LAYUPS = {"Quasi-isotropic 25/50/25": layup(.25, .50, .25),
          "Tailored 50/40/10": layup(.50, .40, .10),
          "Hard 60/30/10": layup(.60, .30, .10)}


def table_w(basis="ultimate", eps=None):
    rng = np.random.default_rng(SEED)
    w, ci, ai, aux = derive_w(200000, rng, basis=basis, eps_design=eps)
    out = {}
    for j, c in enumerate(CRITERIA):
        for i, a in enumerate(ALLOYS):
            m = (ci == j) & (ai == i)
            out[c + " | " + a] = [round(100 * v, 1) for v in pct(w[m])] + [round(float((w[m] <= 0).mean()), 3)]
    out["All structure (mixed)"] = [round(100 * v, 1) for v in pct(w)] + [round(float((w <= 0).mean()), 3)]
    pos = w[w > 0]
    out["Viable only (w>0)"] = [round(100 * v, 1) for v in pct(pos)]
    out["share_strength_draws_unfavourable"] = round(float((w[ci == 2] <= 0).mean()), 3)
    return out


def w0(al, Ex, eps, crit, basis="ultimate"):
    r = LAMINA["rho"] / al["rho"]
    if crit == "bending":
        return 1 - r * (al["E"] / Ex) ** (1 / 3)
    if crit == "inplane":
        return 1 - r * (al["E"] / Ex)
    return 1 - r * al_strength_allowable(al, basis) / (Ex * eps)


def layup_table():
    rows = {}
    for name, seq in LAYUPS.items():
        Ex = laminate_inplane(seq, LAMINA)["Ex"]
        row = {"Ex_GPa": round(Ex / 1e9, 1), "sigma_allow_MPa": round(Ex * EPS_DESIGN / 1e6)}
        for an, al in ALLOYS.items():
            row[an + " bending"] = round(100 * w0(al, Ex, EPS_DESIGN, "bending"), 1)
            row[an + " strength"] = round(100 * w0(al, Ex, EPS_DESIGN, "strength"), 1)
            row[an + " breakeven_eps"] = round(LAMINA["rho"] / al["rho"] * al_strength_allowable(al) / Ex, 5)
        rows[name] = row
    return rows


def strain_sweep():
    out = {}
    for name in ("Quasi-isotropic 25/50/25", "Tailored 50/40/10"):
        Ex = laminate_inplane(LAYUPS[name], LAMINA)["Ex"]
        for eps in (0.0030, 0.0035, 0.0040, 0.0045, 0.0050, 0.0055, 0.0060):
            out[f"{name} | eps={eps:.4f}"] = {an: round(100 * w0(al, Ex, eps, "strength"), 1) for an, al in ALLOYS.items()}
    # dense curve for the figure
    eps = np.linspace(0.003, 0.0065, 71)
    curve = {}
    for name in ("Quasi-isotropic 25/50/25", "Tailored 50/40/10"):
        Ex = laminate_inplane(LAYUPS[name], LAMINA)["Ex"]
        for an, al in ALLOYS.items():
            curve[name + " | " + an] = [round(100 * w0(al, Ex, e, "strength"), 3) for e in eps]
    return out, dict(eps=[round(float(e), 5) for e in eps], curves=curve)


def perturbation(n=20000, seed=5):
    rng = np.random.default_rng(seed)
    rows = []
    for _ in range(n):
        lam = dict(LAMINA)
        for key in ("E1", "E2", "G12", "nu12"):
            lam[key] *= rng.uniform(0.95, 1.05)
        lam["rho"] *= rng.uniform(0.98, 1.02)
        Ex = laminate_inplane(QI, lam)["Ex"]
        row = [Ex / 1e9]
        for an in ALLOYS:
            al = dict(ALLOYS[an])
            for k in ("E", "Fty", "Ftu"):
                al[k] *= rng.uniform(0.95, 1.05)
            al["rho"] *= rng.uniform(0.99, 1.01)
            r = lam["rho"] / al["rho"]
            row += [1 - r * (al["E"] / Ex) ** (1 / 3), 1 - r * al_strength_allowable(al) / (Ex * EPS_DESIGN)]
        rows.append(row)
    R = np.array(rows)
    names = ["E_x (GPa)", "2024 bending", "2024 strength", "7075 bending", "7075 strength"]
    out = {nm: [round(float(np.percentile(R[:, i], p)), 3) for p in (5, 50, 95)] for i, nm in enumerate(names)}
    out["P(2024 strength saving > 0)"] = round(float((R[:, 2] > 0).mean()), 4)
    out["P(7075 strength saving > 0)"] = round(float((R[:, 4] > 0).mean()), 4)
    return out


def calibrate_phi(target=0.20):
    rng = np.random.default_rng(11)
    _, _, _, aux = derive_w(200000, rng, phi_tri=(1.0, 1.0000001, 1.0000002))
    ratio = aux["ratio"]
    f = lambda p: np.median(1 - p * ratio) - target
    try:
        return round(float(brentq(f, 0.5, 2.0)), 3)
    except ValueError:
        return None


def scenario(w, k, FH, v, eAl, btfA, sc, eCF, btfC, eproc=5.0, wf=0.64, eres=4.215):
    Al = btfA * eAl - (btfA - 1) * sc * (eAl - E_REC)
    C = (1 - w) * (btfC * (wf * eCF + (1 - wf) * eres) + eproc)
    co2 = w * k * FH * v / 1000 * EF
    dE = C - Al
    if dE <= 0:
        pay, share = "n.d.", "n.d."
    elif co2 <= 0:
        pay, share = "never", "never"
    else:
        pay = round(dE * FH / co2); share = round(100 * dE / co2, 1)
    return {"w": w, "B_Al": round(Al, 1), "B_C": round(C, 1), "avoided_CO2": round(co2),
            "net_benefit": round(co2 - dE), "payback_FH": pay, "payback_pct_of_life": share}


def main():
    out = {"table_w": table_w(), "table_w_mixed_basis": table_w(basis="mixed"),
           "layups": layup_table(), "perturbation_5pct": perturbation(),
           "phi_for_median_w_0.20": calibrate_phi()}
    out["strain_sweep"], out["strain_curve"] = strain_sweep()
    variants = {
        "main": dict(w_mode="derived_selective"),
        "independent": dict(w_mode="derived_selective", corr=False),
        "indiscriminate": dict(w_mode="derived_all"),
        "empirical": dict(w_mode="empirical"),
        "forward": dict(w_mode="derived_selective", price="forward"),
        "forward_eol": dict(w_mode="derived_selective", price="forward", eol=True),
        "mixed_basis": dict(w_mode="derived_selective", basis="mixed"),
        "mixed_basis_indiscriminate": dict(w_mode="derived_all", basis="mixed"),
        "eps005_indiscriminate": dict(w_mode="derived_all", eps_design=0.005),
        "tailored_strength_selective": dict(w_mode="derived_selective", strength_layup=LAYUPS["Tailored 50/40/10"]),
        "tailored_strength_indiscriminate": dict(w_mode="derived_all", strength_layup=LAYUPS["Tailored 50/40/10"]),
    }
    keep = ("w", "dE_kg", "net_kg", "P_net_positive", "P_dE_positive", "share_ets", "co2_per_kg_saved",
            "co2_saved_kg", "Al_burden", "CFRP_burden", "ratio_co2_over_CFRP", "WP_fuel", "WP_ets", "WP_tot",
            "P_share_gt_15", "P_share_gt_20")
    for name, kw in variants.items():
        r, g, extra = model4.run(**kw)
        d = {k: r[k] for k in keep}
        d["spearman_net"] = r["spearman_net"]; d["spearman_share"] = r["spearman_share"]
        if extra["ci"] is not None:
            neg = extra["net"] <= 0
            d["neg_tail_strength_share"] = float((extra["ci"][neg] == 2).mean()) if neg.any() else None
            d["P_net_positive_by_criterion"] = {CRITERIA[j]: (float((extra["net"][extra["ci"] == j] > 0).mean()) if (extra["ci"] == j).any() else None) for j in range(3)}
            d["w_by_criterion_alloy"] = {CRITERIA[j] + " | " + a: ([round(100*v,1) for v in pct(g["w"][(extra["ci"] == j) & (extra["ai"] == i)])] if ((extra["ci"] == j) & (extra["ai"] == i)).any() else None) for j in range(3) for i, a in enumerate(ALLOYS)}
        out["mc_" + name] = d
    wm = out["mc_tailored_strength_selective"]["w"][1]
    w75 = out["table_w"]["Strength | 7075-T6"][1] / 100
    w24 = out["table_w"]["Strength | 2024-T3"][1] / 100
    fav = dict(eAl=6.7, btfA=1.5, sc=1.0)
    out["scenarios"] = {
        "Central": scenario(round(wm, 3), 0.025, 70000, 700, 10.9, 8.0, 0.5, 24.0, 1.30),
        "Metal-favourable": scenario(round(wm, 3), 0.025, 70000, 700, eCF=24.0, btfC=1.30, **fav),
        "Strength-critical 2024-T3, quasi-isotropic": scenario(round(w24, 3), 0.025, 70000, 700, eCF=24.0, btfC=1.30, **fav),
        "Strength-critical 7075-T6, quasi-isotropic": scenario(round(w75, 3), 0.025, 70000, 700, eCF=24.0, btfC=1.30, **fav),
        "Adverse corner": scenario(0.050, 0.020, 50000, 600, eCF=34.1, btfC=1.45, eproc=10.0, wf=0.68, eres=6.43, **fav),
        "Regional, metal-favourable": scenario(round(wm * 0.195 / 0.234, 3), 0.020, 20000, 450, eCF=24.0, btfC=1.30, **fav),
    }
    return out


if __name__ == "__main__":
    res = main()
    json.dump(res, open("results_revision.json", "w"), indent=1)
    print(json.dumps({k: v for k, v in res.items() if k != "strain_curve"}, indent=1))
